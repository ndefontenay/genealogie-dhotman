# Hotman genealogy recovery site

Static-site starter for preserving the former `audcent.com/hotman.htm` genealogy.

## Recommended recovery process

1. Open the Wayback Machine capture list for `http://audcent.com/hotman.htm`.
2. Choose a late capture, ideally close to the indexed 24 Nov 2015 revision.
3. Save the archived HTML as `source/original-hotman.htm`.
4. Also save/download any image folder created by the browser into `source/`.
5. Run:

   `python tools/import_original.py`

6. Compare `hotman-original-preserved.htm` with the archived page.
7. Copy any missing images into `assets/` and repair links.
8. Publish the folder with GitHub Pages or Cloudflare Pages.

## Why retain `hotman.htm`?

External genealogy sites still cite the historic filename and anchors. Keeping it provides continuity for old links.

## Suggested repository policy

- `source/`: untouched recovered captures
- `hotman-original-preserved.htm`: minimally altered preservation copy
- `hotman.htm`: maintained public edition
- Git history: record every correction and source attribution
