from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[1]
src = ROOT / "source" / "original-hotman.htm"
out = ROOT / "hotman-original-preserved.htm"

if not src.exists():
    raise SystemExit("Missing source/original-hotman.htm. Save the archived page there first.")

text = src.read_text(encoding="utf-8", errors="replace")
# Remove Wayback toolbar/script injection when present while preserving page content.
text = re.sub(r'<!-- BEGIN WAYBACK TOOLBAR INSERT -->.*?<!-- END WAYBACK TOOLBAR INSERT -->', '', text, flags=re.S|re.I)
text = re.sub(r'<script[^>]+src=["\'][^"\']*archive\.org[^"\']*["\'][^>]*></script>', '', text, flags=re.I)
# Rewrite common original-site absolute links back to relative paths.
text = re.sub(r'https?://(?:www\.)?audcent\.com/', '', text, flags=re.I)
# Add an unobtrusive preservation banner immediately after body.
banner = '''\n<div style="padding:10px 16px;background:#fff3cd;border-bottom:1px solid #d6c37a;font:14px Arial,sans-serif">Preserved copy of the former audcent.com genealogy page. Original research credited to David B. Audcent and contributors.</div>\n'''
text = re.sub(r'(<body[^>]*>)', r'\1' + banner, text, count=1, flags=re.I)
out.write_text(text, encoding="utf-8")
print(f"Wrote {out}")
